
<?php
 
                  
    $response = array();
    
  

// check for required fields
if (isset($_POST['location'])  && isset($_POST['reason']) && isset($_POST['public_institution']) && isset($_POST['description'])){
 
    $location = $_POST['location'];
    $reason = $_POST['reason'];
   $public_institution = $_POST['public_institution'];
   $description = $_POST['description'];
     
	
      // include db connect class
     // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();



	$query=mysql_query("select * from citizenalert where location='".$location."' ") or die(mysql_error());
      $duplicate=mysql_num_rows($query);
   if($duplicate==0)
    {
			
 $sql= mysql_query(" INSERT   ignore INTO citizenalert(location, reason, public_institution, description) VALUES ('$location', '$reason', '$public_institution', '$description')");
		
           // check if row inserted or not
} 

 if ($sql) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "account successfully created.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! account not created.";
 

        }     

}
else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
    echo  "  success" ;
    // echoing JSON response
    echo json_encode($response);
}

 ?>
  