<html>

    <form     action="login2.php" method="POST" style="border: 1px solid #DDD;">
      <label><span class="style7"><br />
      </span></label>
      <table  cellspacing="10" cellpadding="0" style="color:#FFD300">
	  
        
        <tr>
          <td ><label     >
            <input type="text" name="name" id="name" placeholder="user name"   style="width: 300px; height:30px;text-indent:30px; background: white url(img/gmarker5.png) left no-repeat;"  required />
          </label></td>
        </tr>
		
		<tr>
          
      <td><label style="width:80px;" >
            <input type="password" name="password"  id="password" placeholder="password" style="width: 300px; height:30px; "  required /></label></td>
	
        </tr>
		
		
         </label></td>
	 <tr>
          <td margin-letf= "10"><label>
            <input type="submit" name="Submit" value="login"  style="width: 52px; height:30px; margin-left:95px;" />
          </label></td>
        </tr>
		
        
      </table>
        
      </form>  
</table>	  
	  </div>
	  
</body>
</html>