<html>

    <form     action="citizenalert.php" method="post" style="border: 1px solid #DDD;">
      <label><span class="style7"><br />
      </span></label>
      <table  cellspacing="10" cellpadding="0" style="color:#FFD300">
	  
        
        <tr>
          <td ><label     >
            <input type="text" name="location" id="location" placeholder="user name"   style="width: 300px; height:30px;text-indent:30px; background: white url(img/gmarker5.png) left no-repeat;"  required />
          </label></td>
        </tr>
		
		<tr>
          
      <td><label style="width:80px;" >
            <input type="text" name="reason"  id="reason" placeholder="reason" style="width: 300px; height:30px; "  required /></label></td>
	
        </tr>
		
		
        <tr>
          
          <td><label style="width:80px;" >
            <input type="text" name="public_institution"  id="public_institutition" placeholder="Phone Number" style="width: 300px; height:30px; "  required /></label></td>
         
        </tr>
  <tr>
          
          <td><label style="width:80px;" >
            <input type="text" name="description"  id="description" placeholder="Phone Number" style="width: 300px; height:30px; "  required /></label></td>
         
        </tr>

         </label></td>
	 <tr>
          <td margin-letf= "10"><label>
            <input type="submit" name="Submit" value="Alert"  style="width: 52px; height:30px; margin-left:95px;" />
            <input type="reset" name="Submit2" value="Cancel" style="width: 52px;height:30px;"/>
          </label></td>
        </tr>
		
        
      </table>
        
      </form>  
</table>	  
	  </div>
	  
</body>
</html>