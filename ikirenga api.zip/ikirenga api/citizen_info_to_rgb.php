<?php
   // include db connect class
     // include db connect class
    require_once __DIR__ . '/db_connect.php';
    // connecting to db
    $db = new DB_CONNECT();

  $sql=mysql_query("select * from citizenalert");
  while($row=mysql_fetch_assoc($sql))
  $output[]=$row;
  json_encode($output);
  print(json_encode($output));
?>