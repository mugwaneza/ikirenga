<?php




    $response = array();
    
    // include db connect class
     // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();
 
if (isset($_POST['name']) && isset($_POST['password'])) {
$name = $_POST['name'];
$password = $_POST['password'];

$query_search = "select * from users where name = '".$name."' AND password = '".$password. "' ";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
//echo $rows;
    
 if($rows == 0) { 
 echo "No Such User Found"; 
 }
else if ($rows != 0) {
$query_search = "select * from users where name = 'kamana' AND password = 'aime' ";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);


 	 echo "hi"; 
 	}

 else  {
    echo "User Found"; 
}
}
?>